<?php
/*
Plugin Name:  Parco - Portfolio
Plugin URI:   https://www.blob.cl
Description:  Este plugin añade la opción de crear un Portfolio para el tema Parco
Version:      1.0
Author:       Angello López
Author URI:   http://www.blob.cl
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  parco
Domain Path:  /languages
*/

require_once('includes/post-type-proyecto.php');
require_once('includes/taxonomy-area.php');