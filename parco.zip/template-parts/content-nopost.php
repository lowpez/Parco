<div class="col-md-12 post-col">
    <article class="post">
        <div class="post-content">
            <h2 class="post-title"><?php _e('No hay contenido para mostrar', 'parco'); ?></h2>
            <div class="post-excerpt">
                <p><?php _e('No hay contenido en esta página, por favor realiza una nueva búsqueda', 'parco'); ?></p>
            </div>
        </div>
    </article>
</div>